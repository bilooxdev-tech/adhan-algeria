# Build Adhan Algeria APK

1. Create a GitHub repository.
2. Upload all project files to the repository.
3. Open the **Actions** tab.
4. Select **Build APK**.
5. Press **Run workflow** (or push to main/master).
6. When it finishes, open the workflow run.
7. Download the artifact named **adhan-algeria-apk**.
