package com.biloox.adhan_algeria
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
