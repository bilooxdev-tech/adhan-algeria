/// ثوابت عامة تُستخدم في أنحاء التطبيق.
/// إبقاء هذه القيم في مكان واحد يسهّل التعديل لاحقًا دون المساس بمنطق العمل.
class AppConstants {
  AppConstants._();

  static const String appName = 'أذان الجزائر';

  /// إحداثيات الكعبة المشرفة (تُستخدم في حساب اتجاه القبلة والمسافة)
  static const double kaabaLatitude = 21.4225;
  static const double kaabaLongitude = 39.8262;

  /// مفاتيح التخزين المحلي (Hive boxes)
  static const String settingsBoxName = 'settings_box';
  static const String locationBoxName = 'location_box';
  static const String prayerTimesCacheBoxName = 'prayer_times_cache_box';

  /// مفاتيح إعدادات الأذان لكل صلاة (تُستخدم كمفاتيح داخل صندوق الإعدادات)
  static const String keyCalculationMethod = 'calculation_method';
  static const String keyMadhab = 'madhab';
  static const String keyManualOffsets = 'manual_offsets';
  static const String keyThemeMode = 'theme_mode';
  static const String keySelectedWilayaCode = 'selected_wilaya_code';
  static const String keySelectedBaladiya = 'selected_baladiya';
  static const String keyUseGps = 'use_gps';

  /// أسماء الصلوات الخمس بالترتيب (تُستخدم كمفاتيح داخلية، وليست للعرض المباشر)
  static const List<String> prayerKeys = [
    'fajr',
    'dhuhr',
    'asr',
    'maghrib',
    'isha',
  ];
}
