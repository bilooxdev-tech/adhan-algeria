import 'package:flutter/material.dart';

/// لوحة ألوان مستوحاة من الهوية الجزائرية (أخضر/أبيض) بشكل عصري وهادئ،
/// مع نسخة للوضع الليلي. لا تُستخدم الألوان مباشرة في الواجهات؛ بل عبر
/// [Theme.of(context).colorScheme] كي يسهل تبديل الوضع الليلي تلقائيًا.
class AppColors {
  AppColors._();

  // الأخضر الجزائري كلون أساسي
  static const Color primaryGreen = Color(0xFF0B6E4F);
  static const Color primaryGreenDark = Color(0xFF16A673);

  static const Color accentGold = Color(0xFFC9A227); // لمسة ذهبية بسيطة

  static const Color lightBackground = Color(0xFFF7F8F5);
  static const Color lightSurface = Color(0xFFFFFFFF);

  static const Color darkBackground = Color(0xFF0F1512);
  static const Color darkSurface = Color(0xFF16201C);

  static const Color textPrimaryLight = Color(0xFF1A1F1C);
  static const Color textPrimaryDark = Color(0xFFEDEFEC);
}
