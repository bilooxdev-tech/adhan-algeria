import 'package:flutter/material.dart';
import 'app_colors.dart';

/// يوفّر ThemeData للوضعين الفاتح والداكن. اعتماد MaterialApp على
/// themeMode (system/light/dark) يتم من مكان واحد في main.dart، بحيث
/// يمكن للمستخدم التحكم فيه من شاشة الإعدادات لاحقًا.
class AppTheme {
  AppTheme._();

  static const String fontFamily = 'Tajawal';

  static ThemeData get light {
    final colorScheme = ColorScheme.light(
      primary: AppColors.primaryGreen,
      secondary: AppColors.accentGold,
      surface: AppColors.lightSurface,
    );

    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: AppColors.lightBackground,
      fontFamily: fontFamily,
      textTheme: _textTheme(AppColors.textPrimaryLight),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        foregroundColor: AppColors.textPrimaryLight,
      ),
    );
  }

  static ThemeData get dark {
    final colorScheme = ColorScheme.dark(
      primary: AppColors.primaryGreenDark,
      secondary: AppColors.accentGold,
      surface: AppColors.darkSurface,
    );

    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: AppColors.darkBackground,
      fontFamily: fontFamily,
      textTheme: _textTheme(AppColors.textPrimaryDark),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        foregroundColor: AppColors.textPrimaryDark,
      ),
    );
  }

  static TextTheme _textTheme(Color baseColor) {
    return TextTheme(
      displayLarge: TextStyle(color: baseColor, fontWeight: FontWeight.bold),
      headlineMedium:
          TextStyle(color: baseColor, fontWeight: FontWeight.bold),
      titleLarge: TextStyle(color: baseColor, fontWeight: FontWeight.w700),
      bodyLarge: TextStyle(color: baseColor),
      bodyMedium: TextStyle(color: baseColor),
    );
  }
}
