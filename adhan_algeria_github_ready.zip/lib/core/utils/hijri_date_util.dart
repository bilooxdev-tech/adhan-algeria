import 'package:hijri/hijri_calendar.dart';
import 'package:intl/intl.dart';

/// أسماء الأشهر الهجرية بالعربية (لا تعتمد على تعريب المكتبة الافتراضي
/// حتى نضمن التحكم الكامل بالنص المعروض).
const List<String> _hijriMonthsAr = [
  'محرم',
  'صفر',
  'ربيع الأول',
  'ربيع الآخر',
  'جمادى الأولى',
  'جمادى الآخرة',
  'رجب',
  'شعبان',
  'رمضان',
  'شوال',
  'ذو القعدة',
  'ذو الحجة',
];

class HijriDateUtil {
  HijriDateUtil._();

  /// يُرجع نصًا جاهزًا للعرض مثل: "12 ربيع الأول 1447هـ"
  static String formatHijri(DateTime gregorianDate) {
    final hijri = HijriCalendar.fromDate(gregorianDate);
    final monthName = _hijriMonthsAr[hijri.hMonth - 1];
    return '${hijri.hDay} $monthName ${hijri.hYear}هـ';
  }

  /// يُرجع التاريخ الميلادي بصيغة عربية مثل: "26 سبتمبر 2026"
  static String formatGregorian(DateTime date) {
    final formatter = DateFormat.yMMMMd('ar');
    return formatter.format(date);
  }
}
