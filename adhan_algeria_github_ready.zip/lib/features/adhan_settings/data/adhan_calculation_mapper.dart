import 'package:adhan_dart/adhan_dart.dart';

import '../domain/adhan_settings_entity.dart';

/// يعزل هذا الملف وحده الاعتماد المباشر على أسماء API الخاصة بمكتبة
/// adhan_dart، بحيث لو تغيّرت المكتبة مستقبلًا (أو استبدلناها) يكفي
/// تعديل هذا الملف فقط دون المساس ببقية طبقات التطبيق.
class AdhanCalculationMapper {
  AdhanCalculationMapper._();

  static CalculationParameters toLibraryParameters(
    AdhanSettingsEntity settings,
  ) {
    final params = _presetFor(settings.calculationMethod);
    params.madhab = _madhabFor(settings.madhab);

    final offsets = settings.manualOffsets;
    params.adjustments[Prayer.fajr] = offsets.fajr;
    params.adjustments[Prayer.sunrise] = offsets.sunrise;
    params.adjustments[Prayer.dhuhr] = offsets.dhuhr;
    params.adjustments[Prayer.asr] = offsets.asr;
    params.adjustments[Prayer.maghrib] = offsets.maghrib;
    params.adjustments[Prayer.isha] = offsets.isha;

    return params;
  }

  static CalculationParameters _presetFor(PrayerCalculationMethod method) {
    switch (method) {
      case PrayerCalculationMethod.algerian:
        return CalculationMethodParameters.algerian();
      case PrayerCalculationMethod.muslimWorldLeague:
        return CalculationMethodParameters.muslimWorldLeague();
      case PrayerCalculationMethod.ummAlQura:
        return CalculationMethodParameters.ummAlQura();
      case PrayerCalculationMethod.egyptian:
        return CalculationMethodParameters.egyptian();
      case PrayerCalculationMethod.tunisia:
        return CalculationMethodParameters.tunisia();
      case PrayerCalculationMethod.morocco:
        return CalculationMethodParameters.morocco();
      case PrayerCalculationMethod.karachi:
        return CalculationMethodParameters.karachi();
      case PrayerCalculationMethod.northAmerica:
        return CalculationMethodParameters.northAmerica();
      case PrayerCalculationMethod.gulfRegion:
        return CalculationMethodParameters.gulfRegion();
      case PrayerCalculationMethod.kuwait:
        return CalculationMethodParameters.kuwait();
      case PrayerCalculationMethod.qatar:
        return CalculationMethodParameters.qatar();
    }
  }

  static Madhab _madhabFor(AsrMadhab madhab) {
    switch (madhab) {
      case AsrMadhab.shafi:
        return Madhab.shafi;
      case AsrMadhab.hanafi:
        return Madhab.hanafi;
    }
  }
}
