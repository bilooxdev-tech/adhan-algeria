/// طرق الحساب المدعومة. القيم مطابقة تمامًا لما توفره مكتبة adhan_dart
/// (راجع lib/features/adhan_settings/data/adhan_calculation_mapper.dart)
/// حتى لا نفترض وجود طريقة غير مدعومة فعليًا في المكتبة الفلكية.
/// [algerian] هي طريقة وزارة الشؤون الدينية والأوقاف الجزائرية، وهي
/// الافتراضية في هذا التطبيق لأنه موجّه للمستخدم الجزائري تحديدًا.
enum PrayerCalculationMethod {
  algerian, // وزارة الشؤون الدينية والأوقاف - الجزائر (الافتراضية)
  muslimWorldLeague, // رابطة العالم الإسلامي
  ummAlQura, // أم القرى - مكة المكرمة
  egyptian, // الهيئة المصرية العامة للمساحة
  tunisia, // وزارة الشؤون الدينية - تونس
  morocco, // وزارة الأوقاف والشؤون الإسلامية - المغرب
  karachi, // جامعة العلوم الإسلامية - كراتشي
  northAmerica, // ISNA - أمريكا الشمالية
  gulfRegion, // منطقة الخليج
  kuwait,
  qatar,
}

enum AsrMadhab { shafi, hanafi }

/// فروقات يدوية بالدقائق لكل صلاة (يمكن أن تكون موجبة أو سالبة).
class ManualPrayerOffsets {
  final int fajr;
  final int sunrise;
  final int dhuhr;
  final int asr;
  final int maghrib;
  final int isha;

  const ManualPrayerOffsets({
    this.fajr = 0,
    this.sunrise = 0,
    this.dhuhr = 0,
    this.asr = 0,
    this.maghrib = 0,
    this.isha = 0,
  });

  ManualPrayerOffsets copyWith({
    int? fajr,
    int? sunrise,
    int? dhuhr,
    int? asr,
    int? maghrib,
    int? isha,
  }) {
    return ManualPrayerOffsets(
      fajr: fajr ?? this.fajr,
      sunrise: sunrise ?? this.sunrise,
      dhuhr: dhuhr ?? this.dhuhr,
      asr: asr ?? this.asr,
      maghrib: maghrib ?? this.maghrib,
      isha: isha ?? this.isha,
    );
  }

  Map<String, int> toMap() => {
        'fajr': fajr,
        'sunrise': sunrise,
        'dhuhr': dhuhr,
        'asr': asr,
        'maghrib': maghrib,
        'isha': isha,
      };

  factory ManualPrayerOffsets.fromMap(Map<dynamic, dynamic> map) {
    return ManualPrayerOffsets(
      fajr: map['fajr'] ?? 0,
      sunrise: map['sunrise'] ?? 0,
      dhuhr: map['dhuhr'] ?? 0,
      asr: map['asr'] ?? 0,
      maghrib: map['maghrib'] ?? 0,
      isha: map['isha'] ?? 0,
    );
  }
}

/// حالة تفعيل الأذان لكل صلاة على حدة + الصوت المختار ومستوى الصوت.
class PerPrayerAdhanSettings {
  final bool enabled;
  final String soundId; // معرّف صوت الأذان المختار من قائمة الأصوات المتاحة
  final double volume; // 0.0 - 1.0
  final bool reminderBeforeEnabled;
  final int reminderMinutesBefore;

  const PerPrayerAdhanSettings({
    this.enabled = true,
    this.soundId = 'default',
    this.volume = 1.0,
    this.reminderBeforeEnabled = false,
    this.reminderMinutesBefore = 10,
  });
}

/// الإعدادات الكاملة لحساب وتشغيل الأذان، مجمّعة ككائن واحد قابل
/// للتخزين في Hive وقابل للتمرير عبر Riverpod كمصدر حقيقة وحيد.
class AdhanSettingsEntity {
  final PrayerCalculationMethod calculationMethod;
  final AsrMadhab madhab;
  final ManualPrayerOffsets manualOffsets;
  final Map<String, PerPrayerAdhanSettings> perPrayerSettings;

  const AdhanSettingsEntity({
    required this.calculationMethod,
    required this.madhab,
    required this.manualOffsets,
    required this.perPrayerSettings,
  });

  factory AdhanSettingsEntity.defaults() {
    return const AdhanSettingsEntity(
      calculationMethod: PrayerCalculationMethod.algerian,
      madhab: AsrMadhab.shafi,
      manualOffsets: ManualPrayerOffsets(),
      perPrayerSettings: {
        'fajr': PerPrayerAdhanSettings(),
        'dhuhr': PerPrayerAdhanSettings(),
        'asr': PerPrayerAdhanSettings(),
        'maghrib': PerPrayerAdhanSettings(),
        'isha': PerPrayerAdhanSettings(),
      },
    );
  }

  AdhanSettingsEntity copyWith({
    PrayerCalculationMethod? calculationMethod,
    AsrMadhab? madhab,
    ManualPrayerOffsets? manualOffsets,
    Map<String, PerPrayerAdhanSettings>? perPrayerSettings,
  }) {
    return AdhanSettingsEntity(
      calculationMethod: calculationMethod ?? this.calculationMethod,
      madhab: madhab ?? this.madhab,
      manualOffsets: manualOffsets ?? this.manualOffsets,
      perPrayerSettings: perPrayerSettings ?? this.perPrayerSettings,
    );
  }
}
