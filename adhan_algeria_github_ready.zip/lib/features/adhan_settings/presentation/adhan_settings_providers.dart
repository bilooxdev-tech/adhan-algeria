import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/adhan_settings_entity.dart';

/// حالة إعدادات الأذان في الذاكرة فقط لهذه المرحلة، بحيث تعمل مفاتيح
/// التفعيل في واجهة المرحلة 3 فعليًا. القراءة/الكتابة الدائمة من/إلى
/// Hive تُضاف في المرحلة 6 دون تغيير الشكل الذي تعرضه الواجهة.
class AdhanSettingsNotifier extends StateNotifier<AdhanSettingsEntity> {
  AdhanSettingsNotifier() : super(AdhanSettingsEntity.defaults());

  void togglePrayer(String prayerKey, bool enabled) {
    final current = state.perPrayerSettings[prayerKey];
    if (current == null) return;

    final updated = Map<String, PerPrayerAdhanSettings>.from(
      state.perPrayerSettings,
    );
    updated[prayerKey] = PerPrayerAdhanSettings(
      enabled: enabled,
      soundId: current.soundId,
      volume: current.volume,
      reminderBeforeEnabled: current.reminderBeforeEnabled,
      reminderMinutesBefore: current.reminderMinutesBefore,
    );

    state = state.copyWith(perPrayerSettings: updated);
  }

  void updateCalculationMethod(PrayerCalculationMethod method) {
    state = state.copyWith(calculationMethod: method);
  }

  void updateMadhab(AsrMadhab madhab) {
    state = state.copyWith(madhab: madhab);
  }

  /// يحدّث فارقًا واحدًا فقط (بالدقائق) لصلاة معيّنة عبر مفتاحها
  /// النصي (fajr/sunrise/dhuhr/asr/maghrib/isha) دون التأثير على بقية
  /// الفروقات.
  void updateManualOffset(String prayerKey, int minutes) {
    final current = state.manualOffsets;
    final updated = switch (prayerKey) {
      'fajr' => current.copyWith(fajr: minutes),
      'sunrise' => current.copyWith(sunrise: minutes),
      'dhuhr' => current.copyWith(dhuhr: minutes),
      'asr' => current.copyWith(asr: minutes),
      'maghrib' => current.copyWith(maghrib: minutes),
      'isha' => current.copyWith(isha: minutes),
      _ => current,
    };
    state = state.copyWith(manualOffsets: updated);
  }
}

final adhanSettingsProvider =
    StateNotifierProvider<AdhanSettingsNotifier, AdhanSettingsEntity>(
  (ref) => AdhanSettingsNotifier(),
);
