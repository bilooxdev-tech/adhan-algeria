import '../domain/adhan_settings_entity.dart';

/// أسماء عرض عربية لكل طريقة حساب، منفصلة عن الـ enum نفسه حتى يسهل
/// تعديل الصياغة دون المساس بمنطق الحساب.
const Map<PrayerCalculationMethod, String> calculationMethodArabicNames = {
  PrayerCalculationMethod.algerian: 'الجزائر (وزارة الشؤون الدينية)',
  PrayerCalculationMethod.muslimWorldLeague: 'رابطة العالم الإسلامي',
  PrayerCalculationMethod.ummAlQura: 'أم القرى (مكة المكرمة)',
  PrayerCalculationMethod.egyptian: 'الهيئة المصرية العامة للمساحة',
  PrayerCalculationMethod.tunisia: 'تونس (وزارة الشؤون الدينية)',
  PrayerCalculationMethod.morocco: 'المغرب (وزارة الأوقاف)',
  PrayerCalculationMethod.karachi: 'جامعة العلوم الإسلامية - كراتشي',
  PrayerCalculationMethod.northAmerica: 'أمريكا الشمالية (ISNA)',
  PrayerCalculationMethod.gulfRegion: 'منطقة الخليج',
  PrayerCalculationMethod.kuwait: 'الكويت',
  PrayerCalculationMethod.qatar: 'قطر',
};
