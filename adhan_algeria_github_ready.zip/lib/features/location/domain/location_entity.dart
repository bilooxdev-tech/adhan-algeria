/// تمثيل موقع المستخدم، سواء جاء من GPS أو من اختيار يدوي لولاية/بلدية.
class LocationEntity {
  final double latitude;
  final double longitude;
  final String wilayaName;
  final String? baladiyaName;
  final bool isFromGps;

  const LocationEntity({
    required this.latitude,
    required this.longitude,
    required this.wilayaName,
    this.baladiyaName,
    required this.isFromGps,
  });
}

/// تمثيل ولاية جزائرية ضمن قائمة الـ 58 ولاية.
/// البيانات الفعلية للولايات والبلديات ستُحمَّل من ملف JSON منفصل
/// (assets/data/wilayas.json) في مرحلة لاحقة، وليس مكتوبة داخل الكود،
/// تحقيقًا لفصل البيانات عن منطق التطبيق.
class WilayaEntity {
  final String code; // مثال: "16"
  final String nameAr; // مثال: "الجزائر"
  final double latitude;
  final double longitude;
  final List<String> baladiyat;

  const WilayaEntity({
    required this.code,
    required this.nameAr,
    required this.latitude,
    required this.longitude,
    required this.baladiyat,
  });
}
