import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../domain/location_entity.dart';

/// موقع افتراضي مؤقت (الجزائر العاصمة) لتمكين بناء الواجهة والانتقال بين
/// الشاشات في هذه المرحلة. سيُستبدل في المرحلة 5 بمنطق حقيقي يعتمد على:
/// - GPS عبر geolocator عند السماح بالصلاحية.
/// - أو الاختيار اليدوي المحفوظ في Hive.
/// لا تُستخدم هذه القيمة كمصدر حقيقة دائم؛ هي فقط Fallback أثناء التطوير.
final currentLocationProvider = StateProvider<LocationEntity>((ref) {
  return const LocationEntity(
    latitude: 36.7538,
    longitude: 3.0588,
    wilayaName: 'الجزائر',
    baladiyaName: null,
    isFromGps: false,
  );
});
