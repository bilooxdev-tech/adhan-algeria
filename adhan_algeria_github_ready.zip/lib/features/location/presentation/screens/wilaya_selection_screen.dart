import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/location_entity.dart';
import '../providers/location_providers.dart';

/// ⚠️ تعرض حاليًا ولايتين فقط كنموذج (الجزائر ووهران) من ملف
/// assets/data/wilayas.json المبدئي. القائمة الكاملة للـ58 ولاية مع
/// بلدياتها، وتحميلها من الملف فعليًا بدل قيم مكتوبة هنا، ستُضاف في
/// المرحلة 5 (GPS واختيار الولاية والمدينة) دون تغيير شكل هذه الشاشة.
class WilayaSelectionScreen extends ConsumerWidget {
  const WilayaSelectionScreen({super.key});

  static const List<LocationEntity> _sampleLocations = [
    LocationEntity(
      latitude: 36.7538,
      longitude: 3.0588,
      wilayaName: 'الجزائر',
      isFromGps: false,
    ),
    LocationEntity(
      latitude: 35.6971,
      longitude: -0.6337,
      wilayaName: 'وهران',
      isFromGps: false,
    ),
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final current = ref.watch(currentLocationProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('اختيار الولاية')),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _sampleLocations.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (context, index) {
          final location = _sampleLocations[index];
          final isSelected = location.wilayaName == current.wilayaName;

          return ListTile(
            tileColor: Theme.of(context).colorScheme.surface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            title: Text(location.wilayaName),
            trailing: isSelected
                ? Icon(Icons.check_circle,
                    color: Theme.of(context).colorScheme.primary)
                : null,
            onTap: () {
              ref.read(currentLocationProvider.notifier).state = location;
              Navigator.of(context).pop();
            },
          );
        },
      ),
    );
  }
}
