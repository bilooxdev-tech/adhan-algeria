import 'package:adhan_dart/adhan_dart.dart' as adhan;

import '../../../adhan_settings/data/adhan_calculation_mapper.dart';
import '../../../adhan_settings/domain/adhan_settings_entity.dart';
import '../../../location/domain/location_entity.dart';
import '../../domain/entities/prayer_time_entity.dart';

/// يحسب مواقيت يوم كامل عبر محرك adhan_dart الفلكي، بمعزل عن أي منطق
/// عرض. الأوقات التي تُعيدها المكتبة UTC؛ نحوّلها هنا إلى الوقت المحلي
/// للجهاز عبر toLocal()، وهو ما يتوافق مع توقيت الجزائر (UTC+1 طوال
/// السنة، بلا توقيت صيفي) طالما إعدادات الجهاز صحيحة.
class AdhanCalculationDataSource {
  const AdhanCalculationDataSource();

  DailyPrayerTimesEntity calculateForDate({
    required LocationEntity location,
    required AdhanSettingsEntity settings,
    required DateTime date,
  }) {
    final coordinates = adhan.Coordinates(
      location.latitude,
      location.longitude,
    );

    final params = AdhanCalculationMapper.toLibraryParameters(settings);

    final prayerTimes = adhan.PrayerTimes(
      coordinates: coordinates,
      date: date,
      calculationParameters: params,
      precision: true,
    );

    return DailyPrayerTimesEntity(
      date: date,
      fajr: prayerTimes.fajr.toLocal(),
      sunrise: prayerTimes.sunrise.toLocal(),
      dhuhr: prayerTimes.dhuhr.toLocal(),
      asr: prayerTimes.asr.toLocal(),
      maghrib: prayerTimes.maghrib.toLocal(),
      isha: prayerTimes.isha.toLocal(),
    );
  }
}
