/// تمثيل صلاة واحدة داخل منطق العمل (Domain)، بمعزل عن أي مصدر بيانات
/// أو مكتبة حساب فلكي، حتى يمكن تغيير محرك الحساب دون التأثير على الواجهة.
enum PrayerName { fajr, sunrise, dhuhr, asr, maghrib, isha }

class PrayerTimeEntity {
  final PrayerName name;
  final DateTime time;

  const PrayerTimeEntity({
    required this.name,
    required this.time,
  });
}

/// تجميع مواقيت يوم كامل، مع بيانات مساندة (الشروق/الغروب مطلوبة صراحة
/// في متطلبات المشروع، لذا تُخزَّن كحقول منفصلة وليست ضمن قائمة الصلوات
/// الخمس القابلة للتفعيل/التعطيل).
class DailyPrayerTimesEntity {
  final DateTime date;
  final DateTime fajr;
  final DateTime sunrise;
  final DateTime dhuhr;
  final DateTime asr;
  final DateTime maghrib;
  final DateTime isha;

  const DailyPrayerTimesEntity({
    required this.date,
    required this.fajr,
    required this.sunrise,
    required this.dhuhr,
    required this.asr,
    required this.maghrib,
    required this.isha,
  });

  /// قائمة الصلوات الخمس فقط (بدون الشروق) بترتيبها، مفيدة للعرض والجدولة.
  List<PrayerTimeEntity> get fivePrayers => [
        PrayerTimeEntity(name: PrayerName.fajr, time: fajr),
        PrayerTimeEntity(name: PrayerName.dhuhr, time: dhuhr),
        PrayerTimeEntity(name: PrayerName.asr, time: asr),
        PrayerTimeEntity(name: PrayerName.maghrib, time: maghrib),
        PrayerTimeEntity(name: PrayerName.isha, time: isha),
      ];

  /// الصلاة القادمة بالنسبة لوقت معيّن، أو null إذا انتهت كل صلوات اليوم
  /// (عندها يجب على الطبقة الأعلى طلب مواقيت اليوم التالي).
  PrayerTimeEntity? nextPrayerAfter(DateTime now) {
    for (final prayer in fivePrayers) {
      if (prayer.time.isAfter(now)) return prayer;
    }
    return null;
  }
}
