import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../adhan_settings/presentation/adhan_settings_providers.dart';
import '../../../location/presentation/providers/location_providers.dart';
import '../../data/datasources/adhan_calculation_datasource.dart';
import '../../domain/entities/prayer_time_entity.dart';

const _dataSource = AdhanCalculationDataSource();

/// يعيد حساب مواقيت اليوم فعليًا عبر محرك adhan_dart الفلكي، بالاعتماد
/// على الموقع الحالي وإعدادات الحساب. لأنه Provider عادي (وليس
/// StateProvider)، فإن Riverpod يعيد بناءه تلقائيًا كلما تغيّر الموقع
/// أو الإعدادات المرتبط بها عبر ref.watch، دون أي كود يدوي إضافي.
final dailyPrayerTimesProvider = Provider<DailyPrayerTimesEntity>((ref) {
  final location = ref.watch(currentLocationProvider);
  final settings = ref.watch(adhanSettingsProvider);

  return _dataSource.calculateForDate(
    location: location,
    settings: settings,
    date: DateTime.now(),
  );
});

/// يبث الوقت الحالي كل ثانية لتحديث العداد التنازلي دون إعادة بناء
/// الشاشة كاملة؛ الاعتماد عليه محصور في الودجت الذي يعرض العداد.
final tickerProvider = StreamProvider<DateTime>((ref) {
  return Stream.periodic(const Duration(seconds: 1), (_) => DateTime.now());
});
