import 'package:flutter/material.dart';

import '../../../location/presentation/screens/wilaya_selection_screen.dart';
import '../../../qibla/presentation/screens/qibla_screen_placeholder.dart';
import '../../../settings/presentation/screens/settings_screen.dart';
import '../widgets/date_header.dart';
import '../widgets/next_prayer_countdown_card.dart';
import '../widgets/prayer_times_list.dart';
import '../widgets/sunrise_sunset_row.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('أذان الجزائر'),
        actions: [
          IconButton(
            icon: const Icon(Icons.location_city_outlined),
            tooltip: 'اختيار الولاية',
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const WilayaSelectionScreen(),
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            tooltip: 'الإعدادات',
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const SettingsScreen()),
              );
            },
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: const [
            DateHeader(),
            SizedBox(height: 20),
            NextPrayerCountdownCard(),
            SizedBox(height: 16),
            PrayerTimesList(),
            SizedBox(height: 16),
            SunriseSunsetRow(),
            SizedBox(height: 16),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => const QiblaScreenPlaceholder(),
            ),
          );
        },
        icon: const Icon(Icons.explore_outlined),
        label: const Text('القبلة'),
      ),
    );
  }
}
