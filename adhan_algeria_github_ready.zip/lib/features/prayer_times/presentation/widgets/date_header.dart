import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/utils/hijri_date_util.dart';
import '../../../location/presentation/providers/location_providers.dart';

class DateHeader extends ConsumerWidget {
  const DateHeader({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final location = ref.watch(currentLocationProvider);
    final now = DateTime.now();
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.location_on_outlined,
                size: 18, color: theme.colorScheme.primary),
            const SizedBox(width: 4),
            Text(
              location.baladiyaName != null
                  ? '${location.baladiyaName} - ${location.wilayaName}'
                  : location.wilayaName,
              style: theme.textTheme.titleLarge,
            ),
          ],
        ),
        const SizedBox(height: 6),
        Text(
          HijriDateUtil.formatHijri(now),
          style: theme.textTheme.bodyLarge,
        ),
        Text(
          HijriDateUtil.formatGregorian(now),
          style: theme.textTheme.bodyMedium
              ?.copyWith(color: theme.colorScheme.onSurface.withOpacity(0.6)),
        ),
      ],
    );
  }
}
