import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../shared/widgets/app_card.dart';
import '../../domain/entities/prayer_time_entity.dart';
import '../providers/prayer_times_providers.dart';

const Map<PrayerName, String> _prayerDisplayNames = {
  PrayerName.fajr: 'الفجر',
  PrayerName.sunrise: 'الشروق',
  PrayerName.dhuhr: 'الظهر',
  PrayerName.asr: 'العصر',
  PrayerName.maghrib: 'المغرب',
  PrayerName.isha: 'العشاء',
};

class NextPrayerCountdownCard extends ConsumerWidget {
  const NextPrayerCountdownCard({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final dailyTimes = ref.watch(dailyPrayerTimesProvider);
    final tick = ref.watch(tickerProvider).valueOrNull ?? DateTime.now();

    final next = dailyTimes.nextPrayerAfter(tick);

    // إذا انتهت كل صلوات اليوم، نعرض الفجر كأول صلاة (تقريبيًا لهذه
    // المرحلة). الحساب الدقيق لليوم التالي يأتي مع المرحلة 4.
    final displayedPrayer = next ?? dailyTimes.fivePrayers.first;
    final remaining = displayedPrayer.time.difference(tick);
    final safeRemaining = remaining.isNegative ? Duration.zero : remaining;

    final hours = safeRemaining.inHours;
    final minutes = safeRemaining.inMinutes % 60;
    final seconds = safeRemaining.inSeconds % 60;

    String two(int v) => v.toString().padLeft(2, '0');

    return AppCard(
      padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
      child: Column(
        children: [
          Text(
            'الوقت المتبقي لصلاة ${_prayerDisplayNames[displayedPrayer.name]}',
            style: theme.textTheme.titleLarge,
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 12),
          Text(
            '${two(hours)}:${two(minutes)}:${two(seconds)}',
            style: theme.textTheme.displayLarge?.copyWith(
              fontSize: 44,
              color: theme.colorScheme.primary,
            ),
          ),
        ],
      ),
    );
  }
}
