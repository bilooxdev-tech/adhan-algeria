import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../../shared/widgets/app_card.dart';
import '../../../adhan_settings/presentation/adhan_settings_providers.dart';
import '../../domain/entities/prayer_time_entity.dart';
import '../providers/prayer_times_providers.dart';

const Map<PrayerName, String> _names = {
  PrayerName.fajr: 'الفجر',
  PrayerName.dhuhr: 'الظهر',
  PrayerName.asr: 'العصر',
  PrayerName.maghrib: 'المغرب',
  PrayerName.isha: 'العشاء',
};

const Map<PrayerName, IconData> _icons = {
  PrayerName.fajr: Icons.nightlight_round,
  PrayerName.dhuhr: Icons.wb_sunny_outlined,
  PrayerName.asr: Icons.brightness_6_outlined,
  PrayerName.maghrib: Icons.wb_twilight,
  PrayerName.isha: Icons.bedtime_outlined,
};

/// تحويل اسم الصلاة إلى المفتاح النصي المستخدم في خريطة إعدادات الأذان
/// (بدون الشروق، لأنه لا يملك أذانًا أو تفعيلًا/تعطيلًا).
String _prayerNameToKey(PrayerName name) => name.name;

class PrayerTimesList extends ConsumerWidget {
  const PrayerTimesList({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final dailyTimes = ref.watch(dailyPrayerTimesProvider);
    final adhanSettings = ref.watch(adhanSettingsProvider);
    final timeFormatter = DateFormat.jm('ar');

    return AppCard(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      child: Column(
        children: [
          for (final prayer in dailyTimes.fivePrayers)
            _PrayerRow(
              icon: _icons[prayer.name]!,
              label: _names[prayer.name]!,
              time: timeFormatter.format(prayer.time),
              enabled:
                  adhanSettings.perPrayerSettings[_prayerNameToKey(prayer.name)]
                          ?.enabled ??
                      true,
              onChanged: (value) {
                ref
                    .read(adhanSettingsProvider.notifier)
                    .togglePrayer(_prayerNameToKey(prayer.name), value);
              },
            ),
        ],
      ),
    );
  }
}

class _PrayerRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String time;
  final bool enabled;
  final ValueChanged<bool> onChanged;

  const _PrayerRow({
    required this.icon,
    required this.label,
    required this.time,
    required this.enabled,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(icon, color: theme.colorScheme.primary, size: 22),
          const SizedBox(width: 12),
          Expanded(
            child: Text(label, style: theme.textTheme.titleLarge),
          ),
          Text(time, style: theme.textTheme.bodyLarge),
          const SizedBox(width: 8),
          Switch(
            value: enabled,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}
