import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../../shared/widgets/app_card.dart';
import '../providers/prayer_times_providers.dart';

class SunriseSunsetRow extends ConsumerWidget {
  const SunriseSunsetRow({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final dailyTimes = ref.watch(dailyPrayerTimesProvider);
    final formatter = DateFormat.jm('ar');

    return Row(
      children: [
        Expanded(
          child: _MiniInfoCard(
            icon: Icons.wb_sunny_outlined,
            label: 'الشروق',
            value: formatter.format(dailyTimes.sunrise),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _MiniInfoCard(
            icon: Icons.wb_twilight,
            label: 'الغروب',
            value: formatter.format(dailyTimes.maghrib),
          ),
        ),
      ],
    );
  }
}

class _MiniInfoCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _MiniInfoCard({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AppCard(
      child: Column(
        children: [
          Icon(icon, color: theme.colorScheme.primary),
          const SizedBox(height: 6),
          Text(label, style: theme.textTheme.bodyMedium),
          Text(value, style: theme.textTheme.titleLarge),
        ],
      ),
    );
  }
}
