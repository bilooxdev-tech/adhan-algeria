import 'package:flutter/material.dart';

/// شاشة مؤقتة فقط لربط التنقل من الصفحة الرئيسية. الشاشة الحقيقية
/// (بوصلة القبلة، الدرجات، المسافة إلى مكة، صلاحيات الموقع والبوصلة)
/// تُبنى بالكامل في المرحلة 7 كما هو مخطط له.
class QiblaScreenPlaceholder extends StatelessWidget {
  const QiblaScreenPlaceholder({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('اتجاه القبلة')),
      body: const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'شاشة القبلة (بوصلة + درجات + مسافة إلى مكة)\nستُبنى في المرحلة 7.',
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
