import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// حالة الوضع الليلي في الذاكرة فقط حاليًا. سيتم ربطها بالتخزين الدائم
/// في Hive ضمن شاشة الإعدادات الكاملة (لاحقًا ضمن هذه المرحلة نفسها إذا
/// اتسع الوقت، وإلا في مرحلة تحسين الإعدادات).
final themeModeProvider = StateProvider<ThemeMode>((ref) => ThemeMode.system);
