import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../adhan_settings/domain/adhan_settings_entity.dart';
import '../../../adhan_settings/presentation/adhan_settings_providers.dart';
import '../../../adhan_settings/presentation/calculation_method_labels.dart';
import '../providers/theme_mode_provider.dart';

const Map<String, String> _prayerLabelsAr = {
  'fajr': 'الفجر',
  'sunrise': 'الشروق',
  'dhuhr': 'الظهر',
  'asr': 'العصر',
  'maghrib': 'المغرب',
  'isha': 'العشاء',
};

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeModeProvider);
    final adhanSettings = ref.watch(adhanSettingsProvider);
    final notifier = ref.read(adhanSettingsProvider.notifier);

    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const _SectionTitle('المظهر'),
          RadioListTile<ThemeMode>(
            title: const Text('تلقائي (حسب النظام)'),
            value: ThemeMode.system,
            groupValue: themeMode,
            onChanged: (value) =>
                ref.read(themeModeProvider.notifier).state = value!,
          ),
          RadioListTile<ThemeMode>(
            title: const Text('فاتح'),
            value: ThemeMode.light,
            groupValue: themeMode,
            onChanged: (value) =>
                ref.read(themeModeProvider.notifier).state = value!,
          ),
          RadioListTile<ThemeMode>(
            title: const Text('داكن'),
            value: ThemeMode.dark,
            groupValue: themeMode,
            onChanged: (value) =>
                ref.read(themeModeProvider.notifier).state = value!,
          ),
          const Divider(height: 32),
          const _SectionTitle('طريقة حساب مواقيت الصلاة'),
          DropdownButtonFormField<PrayerCalculationMethod>(
            key: ValueKey(adhanSettings.calculationMethod),
            initialValue: adhanSettings.calculationMethod,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
            ),
            items: [
              for (final entry in calculationMethodArabicNames.entries)
                DropdownMenuItem(value: entry.key, child: Text(entry.value)),
            ],
            onChanged: (value) {
              if (value != null) notifier.updateCalculationMethod(value);
            },
          ),
          const SizedBox(height: 16),
          const _SectionTitle('المذهب (لحساب وقت العصر)'),
          SegmentedButton<AsrMadhab>(
            segments: const [
              ButtonSegment(value: AsrMadhab.shafi, label: Text('شافعي')),
              ButtonSegment(value: AsrMadhab.hanafi, label: Text('حنفي')),
            ],
            selected: {adhanSettings.madhab},
            onSelectionChanged: (selection) =>
                notifier.updateMadhab(selection.first),
          ),
          const Divider(height: 32),
          const _SectionTitle('فروقات يدوية لكل صلاة (بالدقائق)'),
          Text(
            'استخدم هذا فقط إذا لاحظت فرقًا ثابتًا بين التطبيق ومسجد '
            'منطقتك، بعد التأكد من صحة طريقة الحساب أعلاه.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 8),
          for (final key in _prayerLabelsAr.keys)
            _ManualOffsetRow(
              label: _prayerLabelsAr[key]!,
              value: _offsetFor(adhanSettings.manualOffsets, key),
              onChanged: (v) => notifier.updateManualOffset(key, v),
            ),
        ],
      ),
    );
  }

  int _offsetFor(ManualPrayerOffsets offsets, String key) {
    return switch (key) {
      'fajr' => offsets.fajr,
      'sunrise' => offsets.sunrise,
      'dhuhr' => offsets.dhuhr,
      'asr' => offsets.asr,
      'maghrib' => offsets.maghrib,
      'isha' => offsets.isha,
      _ => 0,
    };
  }
}

class _ManualOffsetRow extends StatelessWidget {
  final String label;
  final int value;
  final ValueChanged<int> onChanged;

  const _ManualOffsetRow({
    required this.label,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(child: Text(label)),
          IconButton(
            icon: const Icon(Icons.remove_circle_outline),
            onPressed: () => onChanged(value - 1),
          ),
          SizedBox(
            width: 40,
            child: Text(
              value.toString(),
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleLarge,
            ),
          ),
          IconButton(
            icon: const Icon(Icons.add_circle_outline),
            onPressed: () => onChanged(value + 1),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle(this.title);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Text(
        title,
        style: Theme.of(context)
            .textTheme
            .titleLarge
            ?.copyWith(color: Theme.of(context).colorScheme.primary),
      ),
    );
  }
}
