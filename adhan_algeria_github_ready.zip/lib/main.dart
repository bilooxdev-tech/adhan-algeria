import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'core/constants/app_constants.dart';
import 'core/theme/app_theme.dart';
import 'features/prayer_times/presentation/screens/home_screen.dart';
import 'features/settings/presentation/providers/theme_mode_provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // تهيئة التخزين المحلي (Offline-first). فتح الصناديق هنا يضمن توفرها
  // قبل رسم أي واجهة تعتمد عليها.
  await Hive.initFlutter();
  await Hive.openBox(AppConstants.settingsBoxName);
  await Hive.openBox(AppConstants.locationBoxName);
  await Hive.openBox(AppConstants.prayerTimesCacheBoxName);

  // مطلوبة كي يعمل DateFormat.yMMMMd('ar') بأسماء الأشهر العربية بدل
  // رمي استثناء LocaleDataException.
  await initializeDateFormatting('ar');

  runApp(const ProviderScope(child: AdhanAlgeriaApp()));
}

class AdhanAlgeriaApp extends ConsumerWidget {
  const AdhanAlgeriaApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeModeProvider);

    return MaterialApp(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: themeMode,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) {
        // فرض اتجاه RTL على كامل التطبيق بغض النظر عن لغة النظام،
        // لأن التطبيق موجّه بالكامل للمستخدم الناطق بالعربية.
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: const HomeScreen(),
    );
  }
}
